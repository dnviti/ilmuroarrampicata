<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

    // File di configurazione dell'applicazione
    // Usare la variabile $_opzione = $_config["opzione"]
    // per leggere / impostare un'opzione (come in connection.php)
    // per creare una nuova opzione usare un array all'interno di $_config
    /* 
        Es:
            $_config = [
                "opzione" => [
                    "nome" => "valore"
                ]
            ]
 */

 // lasciare vuota
$_projectRoot = "";

$_config = [
    "mysql" => [
        "servername" => "localhost",
        "username" => "ilmuroarrampicata",
        "password" => "W9w4Ke5sTSdu",
        "database" => "my_ilmuroarrampicata"
    ],
    "paths" => [
        "configs" => $_projectRoot . "php/config/",
        "classes" => $_projectRoot . "php/class/",
        "views" => $_projectRoot . "views/",
        "css" => $_projectRoot . "assets/css/",
        "js" => $_projectRoot . "assets/js/",
        "html" => $_projectRoot . "assets/html/",
        "third-part" => $_projectRoot . "assets/third-part/",
        "sql" => $_projectRoot . "assets/sql/",
        "img" => $_projectRoot . "assets/img/"
    ]
];
?>