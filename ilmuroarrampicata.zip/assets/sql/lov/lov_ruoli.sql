select 'Amministratore', '2'
from dual
union
select 'Gestore', '1'
from dual
union
select 'Tesserato', '0'
from dual;